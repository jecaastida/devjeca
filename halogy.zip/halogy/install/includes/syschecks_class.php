<?php

class syschecks {

	// Check PHP Version
	function versionCheckPHP($vcPHP) {

    }
	
	
} 