
			<div id="halogycms_browser" class="loading"></div>

		</div>

	</div>


	<div id="footer" class="content">

		<div class="container">

		
			<p class="copyright">Powered by <a href="http://www.halogy.com" title="Halogy">Halogy</a> Community Edition. <br />
			Page Executed In: {elapsed_time}
			</p>
			
			<br />
			
			<a href="http://www.halogy.com"><img src="<?php echo base_url() . $this->config->item('staticPath'); ?>/images/halogy_marque.gif" alt="Powered by Halogy" /></a>


		</div>

	</div>

</div>
	
</body>
</html>