{include:header}

<div id="tpl-shop" class="container">
	
	<div class="row">

		<h1>Your order has been cancelled</h1>
	
		<p>No payments have been taken and your cart has been emptied.</p>
	
		<p><a href="/shop">Click here</a> to return to the shop.</p>

	</div>
	

</div>
	
{include:footer}