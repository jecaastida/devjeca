{include:header}

<div id="tpl-shop" class="container">

	<div class="row">
        <ul class="nav nav-tabs">
          <li class="active"><a href="#">Featured Products</a></li>
          <li><a href="#">Popular Products</a></li>
          <li><a href="#">Latest Products</a></li>
          <li><a href="#">Menu 3</a></li>
        </ul>
		
        
        <div >
		
		{if shop:featured}
		
		<table class="default">
			<tr>
				{shop:featured}
					{product:rowpad}			
					<td align="center" valign="top" width="{product:cell-width}%">
						<a href="{product:link}">
						<img src="{product:thumb-path}" alt="Product image" class="productpic" />
						<p><strong>{product:title}</strong><br />{product:price}</p></a>
					</td>
				{/shop:featured}
				{rowpad:featured}
			</tr>
		</table>

		{else}

			<p><small>There are currently no featured products.</small></p>
		
		{/if}

        </div>
		<div >
        
        <!--popular-->
		{if shop:popular}
		
		<table class="default">
			<tr>
				{shop:popular}
					{product:rowpad}					
					<td align="center" valign="top" width="{product:cell-width}%">
						<a href="{product:link}">
						<img src="{product:thumb-path}" alt="Product image" class="productpic" />
						<p><strong>{product:title}</strong><br />{product:price}</p></a>
					</td>
				{/shop:popular}
				{rowpad:popular}
			</tr>
		</table>

		{else}

			<p><small>There are currently no products here.</small></p>
		
		{/if}
        
        
        </div>
        
        <div >
        
        <!--latest-->
		<h3>Latest Products</h3>

		{if shop:latest}
		
		<table class="default">
			<tr>
				{shop:latest}
					{product:rowpad}					
					<td align="center" valign="top" width="{product:cell-width}%">
						<a href="{product:link}">
						<img src="{product:thumb-path}" alt="Product image" class="productpic" />
						<p><strong>{product:title}</strong><br />{product:price}</p></a>
					</td>
				{/shop:latest}
				{rowpad:latest}
			</tr>
		</table>

		{else}

			<p><small>There are currently no products here.</small></p>
		
		{/if}
		
        
         </div>
         
         
		<!--h3>Most Viewed</h3>

		{if shop:mostviewed}
		
		<table class="default">
			<tr>
				{shop:mostviewed}
					{product:rowpad}					
					<td align="center" valign="top" width="{product:cell-width}%">
						<a href="{product:link}">
						<img src="{product:thumb-path}" alt="Product image" class="productpic" />
						<p><strong>{product:title}</strong><br />{product:price}</p></a>
					</td>
				{/shop:mostviewed}
				{rowpad:mostviewed}
			</tr>
		</table>

		{else}

			<p><small>There are currently no products here.</small></p>
		
		{/if}-->

	</div>
	

</div>
	
{include:footer}