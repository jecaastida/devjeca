{include:header}

<div id="tpl-shop" class="container">

	<div class="row">

		<h1>Checkout</h1>
		
		{if errors}
			
            <div class="alert alert-danger error">
             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				{errors}
			</div>
		{/if}

		<p>Confirm your order and your dispatch address below is correct, then click on 'Proceed to Payment Page' to make payment. If you want to cancel your order click on the 'Cancel Order' button.</p>			
		
		<p>Your shopping cart contains:</p>
	<div class="table-responsive">
		<table class="table">
			<tr>
				<th>&nbsp;</th><th>&nbsp;</th>
                <th>Product</th>
				<th>Price ({site:currency})</th>
				<th>Quantity</th>
			</tr>
			{cart:items}				
			<tr>
				<td colspan="3" ><hr /></td>
			</tr>
			{if cart:discounts}
				<tr>
					<td colspan="2">Discounts applied:</td>
					<td>({cart:discounts})</td>
				</tr>
			{/if}											
			<tr>
				<td colspan="2">Sub total:</td>
				<td>{cart:subtotal}</td>
			</tr>
			<tr>
				<td colspan="2">Shipping:</td>
				<td>{cart:postage}</td>
			</tr>
			{if cart:tax}
				<tr>
					<td colspan="2">Tax:</td>
					<td>{cart:tax}</td>
				</tr>
			{/if}
			<tr>
				<td colspan="2"><strong>Total amount:</strong></td>
				<td><strong>{cart:total}</strong></td>
			</tr>
			<tr>
				<td colspan="3" ><hr /></td>
			</tr>
		</table>
		</div>
		<div style="float: right;">
			<p><a href="/shop/cart" class="btn btn-default">Update Order</a></p>
		</div>
		
		<br class="clear" />
		
		<table class="table">
			<tr>
				<td width="50%" valign="top">
					<h2>Delivery Address</h2>
				
					<p>
						<strong>Full name:</strong> {user:name}
						<br />
						
						{if user:address1}
							<strong>Address 1:</strong> {user:address1}
							<br />
						{/if}
					
						{if user:address2}
							<strong>Address 2:</strong> {user:address2}
							<br />
						{/if}
						
						{if user:address3}
							<strong>Address 3:</strong> {user:address3}
							<br />
						{/if}
						
						{if user:city}
							<strong>City:</strong> {user:city}
							<br />
						{/if}
						
						{if user:state}
							<strong>State:</strong> {user:state}
							<br />
						{/if}
						
						{if user:postcode}				
							<strong>Post/ZIP code:</strong> {user:postcode}
							<br />
						{/if}
						
						{if user:country}
							<strong>Country:</strong> {user:country}
						{/if}
					</p>
				</td>
				<td width="50%" valign="top">
					<h2>Billing Address</h2>
				
					<p>
						<strong>Full name:</strong> {user:name}
						<br />
						
						{if user:billing-address1}
							<strong>Address 1:</strong> {user:billing-address1}
							<br />
						{/if}
					
						{if user:billing-address2}
							<strong>Address 2:</strong> {user:billing-address2}
							<br />
						{/if}
						
						{if user:billing-address3}
							<strong>Address 3:</strong> {user:billing-address3}
							<br />
						{/if}
						
						{if user:billing-city}
							<strong>City:</strong> {user:billing-city}
							<br />
						{/if}
						
						{if user:billing-state}
							<strong>State:</strong> {user:billing-state}
							<br />
						{/if}
						
						{if user:billing-postcode}				
							<strong>Post/ZIP code:</strong> {user:billing-postcode}
							<br />
						{/if}
						
						{if user:billing-country}
							<strong>Country:</strong> {user:billing-country}
						{/if}
					</p>
				</td>
			</tr>
		</table>
          
                
		<div style="float: right;">
			<p><a href="/shop/account/checkout" class="btn btn-info">Update Address</a></p>
		</div>
		<br class="clear" />
              
		<br />
		
		<form action="/shop/success" method="post" class="default">

			

			<div style="float:right">
				<a href="/shop/cancel" class="btn btn-default">Cancel Order</a>
				<input type="submit" value="Place  Order &gt;" style="font-weight: bold;" class="btn btn-primary" />
			</div>
			<br class="clear" />

		</form>
	
		
		<!-- cards --><p><a href="#" onclick="javascript:window.open('https://www.paypal.com/uk/cgi-bin/webscr?cmd=xpt/Marketing/popup/OLCWhatIsPayPal-outside','olcwhatispaypal','toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=400, height=350');"><img src="https://www.paypal.com/en_GB/GB/i/logo/PayPal_mark_37x23.gif" alt="Payments by Paypal"></a> <img src="/static/images/cards_visa.gif" alt="Visa Accepted" /> <img src="/static/images/cards_electron.gif" alt="Visa Electron Accepted" /> <img src="/static/images/cards_mastercard.gif" alt="Mastercard Accepted" /> <img src="/static/images/cards_visadelta.gif" alt="Visa Delta Accepted" /> <img src="/static/images/cards_switch.gif" alt="Switch Accepted" /> <img src="/static/images/cards_maestro.gif" alt="Maestro Accepted" /> <img src="/static/images/cards_solo.gif" alt="Solo Accepted" /></p>
				
		<p>Your order will be saved on file and will be verify. Onced verified you will receive an email confirmation containing your order details and reference number once the payment process is completed.</p>
		
		
	</div>


</div>
	
{include:footer}